"""
shareholding_dashboard.py
─────────────────────────
Streamlit dashboard for visualising quarterly shareholding patterns
fetched by screener_fetcher.py.

Run with:
    streamlit run shareholding_dashboard.py

Requirements:
    pip install streamlit pandas plotly
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from pathlib import Path

# ─── Page Config ──────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="Shareholding Tracker",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Theme ────────────────────────────────────────────────────────────────────

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&display=swap');

html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }

.metric-card {
    background: #f8f9fa;
    border: 1px solid #e9ecef;
    border-radius: 10px;
    padding: 1rem 1.25rem;
    text-align: center;
}
.metric-label { font-size: 12px; color: #6c757d; margin-bottom: 4px; letter-spacing: 0.04em; }
.metric-val   { font-size: 26px; font-weight: 600; color: #212529; }
.metric-sub   { font-size: 12px; margin-top: 2px; }

.fii-up   { color: #1e7e34; }
.fii-down { color: #c0392b; }
.fii-neu  { color: #6c757d; }

.section-title {
    font-size: 13px;
    font-weight: 500;
    color: #6c757d;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    margin-bottom: 0.5rem;
}
</style>
""", unsafe_allow_html=True)

# ─── Constants ────────────────────────────────────────────────────────────────

MASTER_CSV   = Path("data/shareholding_all.csv")
PER_STOCK_DIR = Path("data/shareholding_screener")

CATEGORY_COLORS = {
    "Promoters": "#5f5e5a",
    "FIIs":      "#378ADD",
    "DIIs":      "#1D9E75",
    "Public":    "#BA7517",
    "Govt":      "#7F77DD",
    "Others":    "#D85A30",
}

# ─── Data Loading ─────────────────────────────────────────────────────────────

@st.cache_data(ttl=3600)
def load_master() -> pd.DataFrame:
    """Load combined shareholding CSV. Falls back to per-stock CSVs if needed."""
    if MASTER_CSV.exists():
        df = pd.read_csv(MASTER_CSV)
        if not df.empty:
            return _clean(df)

    # Try merging per-stock CSVs
    if PER_STOCK_DIR.exists():
        frames = []
        for f in PER_STOCK_DIR.glob("shareholding_*.csv"):
            try:
                tmp = pd.read_csv(f)
                if not tmp.empty:
                    frames.append(tmp)
            except Exception:
                pass
        if frames:
            df = pd.concat(frames, ignore_index=True)
            return _clean(df)

    return pd.DataFrame()


def _clean(df: pd.DataFrame) -> pd.DataFrame:
    df.columns = [c.strip().lower() for c in df.columns]
    rename = {}
    for c in df.columns:
        if "sym"  in c: rename[c] = "symbol"
        elif "qtr" in c or "quarter" in c: rename[c] = "quarter"
        elif "cat" in c: rename[c] = "category"
        elif "pct" in c or "val" in c or "%" in c: rename[c] = "pct"
    df.rename(columns=rename, inplace=True)

    required = {"symbol", "quarter", "category", "pct"}
    if not required.issubset(df.columns):
        st.error(f"CSV is missing columns. Found: {list(df.columns)}")
        return pd.DataFrame()

    df["pct"] = pd.to_numeric(df["pct"], errors="coerce")
    df.dropna(subset=["pct"], inplace=True)
    df["symbol"]   = df["symbol"].str.upper().str.strip()
    df["category"] = df["category"].str.strip()
    return df.reset_index(drop=True)


def sort_quarters(df: pd.DataFrame) -> pd.DataFrame:
    """
    Sort rows so quarters run chronologically.
    Handles formats like 'Mar 2024', 'Jun 2024', 'Q1 FY25', 'Sep 2023', etc.
    """
    month_order = {
        "jan":1,"feb":2,"mar":3,"apr":4,"may":5,"jun":6,
        "jul":7,"aug":8,"sep":9,"oct":10,"nov":11,"dec":12,
        "q1":1,"q2":4,"q3":7,"q4":10,
    }

    def quarter_key(q: str):
        parts = str(q).lower().split()
        for p in parts:
            if p in month_order:
                for part2 in parts:
                    try:
                        yr = int(part2)
                        return yr * 100 + month_order[p]
                    except ValueError:
                        pass
        return 0

    quarters = df["quarter"].unique().tolist()
    sorted_q = sorted(quarters, key=quarter_key)
    df["quarter"] = pd.Categorical(df["quarter"], categories=sorted_q, ordered=True)
    return df.sort_values("quarter")


# ─── Computed metrics ─────────────────────────────────────────────────────────

def latest_value(df: pd.DataFrame, symbol: str, category: str) -> float | None:
    sub = df[(df["symbol"] == symbol) & (df["category"] == category)]
    if sub.empty:
        return None
    sub = sort_quarters(sub.copy())
    return sub.iloc[-1]["pct"]


def qoq_change(df: pd.DataFrame, symbol: str, category: str) -> float | None:
    sub = df[(df["symbol"] == symbol) & (df["category"] == category)]
    if len(sub) < 2:
        return None
    sub = sort_quarters(sub.copy())
    return round(sub.iloc[-1]["pct"] - sub.iloc[-2]["pct"], 2)


# ─── Sidebar ──────────────────────────────────────────────────────────────────

with st.sidebar:
    st.title("📊 Shareholding Tracker")
    st.caption("Source: Screener.in")

    if st.button("🔄 Reload data", use_container_width=True):
        st.cache_data.clear()
        st.rerun()

    df_all = load_master()

    if df_all.empty:
        st.error("No data found.\n\nRun `python screener_fetcher.py` first.")
        st.stop()

    symbols = sorted(df_all["symbol"].unique().tolist())
    categories = sorted(df_all["category"].unique().tolist())

    st.markdown("---")
    st.markdown('<div class="section-title">Filters</div>', unsafe_allow_html=True)

    selected_symbols = st.multiselect(
        "Stocks (leave blank = all)",
        options=symbols,
        default=[],
        placeholder="Select stocks…"
    )
    if not selected_symbols:
        selected_symbols = symbols

    selected_cats = st.multiselect(
        "Categories",
        options=categories,
        default=[c for c in ["Promoters","FIIs","DIIs","Public"] if c in categories],
    )
    if not selected_cats:
        selected_cats = categories

    st.markdown("---")
    st.markdown('<div class="section-title">Sort / Filter overview</div>', unsafe_allow_html=True)

    sort_by = st.selectbox(
        "Sort stocks by",
        ["Symbol A–Z", "FII % ↓", "FII % ↑", "FII QoQ change ↓", "Promoter % ↓"],
    )

    filter_by = st.selectbox(
        "Filter to",
        ["All", "FII increasing", "FII decreasing", "FII > 20%", "FII < 5%"],
    )


# ─── Filter data ──────────────────────────────────────────────────────────────

df = df_all[
    df_all["symbol"].isin(selected_symbols) &
    df_all["category"].isin(selected_cats)
].copy()


# ─── Build summary table ───────────────────────────────────────────────────────

@st.cache_data(ttl=3600)
def build_summary(df_all_hash: str, syms: tuple, cats: tuple) -> pd.DataFrame:
    rows = []
    for sym in syms:
        row = {"symbol": sym}
        for cat in cats:
            latest = latest_value(df_all, sym, cat)
            chg    = qoq_change(df_all, sym, cat)
            row[f"{cat} %"]      = latest
            row[f"{cat} QoQ"]    = chg
        rows.append(row)
    return pd.DataFrame(rows)

summary = build_summary(
    str(len(df_all)),
    tuple(selected_symbols),
    tuple(selected_cats),
)

# Apply filter
if filter_by == "FII increasing":
    summary = summary[summary.get("FIIs QoQ", pd.Series(dtype=float)).fillna(0) > 0]
elif filter_by == "FII decreasing":
    summary = summary[summary.get("FIIs QoQ", pd.Series(dtype=float)).fillna(0) < 0]
elif filter_by == "FII > 20%":
    summary = summary[summary.get("FIIs %", pd.Series(dtype=float)).fillna(0) > 20]
elif filter_by == "FII < 5%":
    summary = summary[summary.get("FIIs %", pd.Series(dtype=float)).fillna(0) < 5]

# Apply sort
if "FII % ↓" in sort_by:
    summary = summary.sort_values("FIIs %", ascending=False)
elif "FII % ↑" in sort_by:
    summary = summary.sort_values("FIIs %", ascending=True)
elif "QoQ" in sort_by:
    summary = summary.sort_values("FIIs QoQ", ascending=False)
elif "Promoter" in sort_by:
    summary = summary.sort_values("Promoters %", ascending=False)
else:
    summary = summary.sort_values("symbol")

filtered_symbols = summary["symbol"].tolist()


# ─── Market-wide stats ────────────────────────────────────────────────────────

st.title("Shareholding Pattern Dashboard")
st.caption(f"Data from Screener.in · {len(symbols)} stocks loaded · {df_all['quarter'].nunique()} quarters")

fii_vals = [latest_value(df_all, s, "FIIs") for s in symbols]
fii_vals = [v for v in fii_vals if v is not None]

fii_chgs = [qoq_change(df_all, s, "FIIs") for s in symbols]
fii_up   = sum(1 for c in fii_chgs if c and c > 0)
fii_dn   = sum(1 for c in fii_chgs if c and c < 0)
fii_avg  = round(sum(fii_vals)/len(fii_vals), 2) if fii_vals else 0

c1, c2, c3, c4, c5 = st.columns(5)
for col, label, val, sub, css in [
    (c1, "Total stocks",   len(symbols),                   "",                    ""),
    (c2, "Avg FII %",      f"{fii_avg}%",                  "across all stocks",   ""),
    (c3, "FII increasing", fii_up,                          "stocks QoQ",          "fii-up"),
    (c4, "FII decreasing", fii_dn,                          "stocks QoQ",          "fii-down"),
    (c5, "Filtered view",  len(filtered_symbols),           f"with '{filter_by}'", ""),
]:
    col.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">{label}</div>
        <div class="metric-val {css}">{val}</div>
        <div class="metric-sub" style="color:#adb5bd">{sub}</div>
    </div>""", unsafe_allow_html=True)

st.markdown("---")


# ─── Tabs ─────────────────────────────────────────────────────────────────────

tab1, tab2, tab3, tab4 = st.tabs([
    "📈 Individual stock",
    "🔢 Summary table",
    "🗺 FII heatmap",
    "📊 Cross-stock compare",
])


# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 — Individual stock trend
# ══════════════════════════════════════════════════════════════════════════════

with tab1:
    col_pick, col_info = st.columns([2, 3])
    with col_pick:
        stock = st.selectbox("Select stock", filtered_symbols or symbols)

    sub = df_all[df_all["symbol"] == stock].copy()
    sub = sort_quarters(sub)

    if sub.empty:
        st.warning(f"No data for {stock}.")
    else:
        # KPI row
        k_cols = st.columns(4)
        for i, cat in enumerate(["Promoters","FIIs","DIIs","Public"]):
            lv  = latest_value(df_all, stock, cat)
            chg = qoq_change(df_all, stock, cat)
            if lv is None:
                continue
            chg_str = (f"+{chg:.2f}%" if chg and chg > 0 else f"{chg:.2f}%") if chg is not None else "—"
            chg_css = "fii-up" if chg and chg > 0 else ("fii-down" if chg and chg < 0 else "fii-neu")
            k_cols[i % 4].markdown(f"""
            <div class="metric-card">
                <div class="metric-label">{cat}</div>
                <div class="metric-val">{lv:.2f}%</div>
                <div class="metric-sub {chg_css}">QoQ: {chg_str}</div>
            </div>""", unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        # Line chart
        fig = go.Figure()
        for cat in sub["category"].unique():
            cat_df = sub[sub["category"] == cat]
            color  = CATEGORY_COLORS.get(cat, "#888")
            dash   = "dot" if cat in ("Promoters", "Public") else "solid"
            fig.add_trace(go.Scatter(
                x=cat_df["quarter"].astype(str),
                y=cat_df["pct"],
                name=cat,
                mode="lines+markers",
                line=dict(color=color, width=2.5, dash=dash),
                marker=dict(size=6),
                hovertemplate=f"<b>{cat}</b><br>Quarter: %{{x}}<br>%{{y:.2f}}%<extra></extra>",
            ))

        fig.update_layout(
            title=f"{stock} — Quarterly shareholding trend",
            xaxis_title="Quarter",
            yaxis_title="Shareholding %",
            yaxis_ticksuffix="%",
            hovermode="x unified",
            template="plotly_white",
            legend=dict(orientation="h", y=-0.2),
            margin=dict(l=40, r=20, t=50, b=60),
            height=420,
        )
        st.plotly_chart(fig, use_container_width=True)

        # Data table
        with st.expander("Raw data table"):
            pivot = sub.pivot_table(index="quarter", columns="category", values="pct").reset_index()
            st.dataframe(
                pivot.style.format({c: "{:.2f}%" for c in pivot.columns if c != "quarter"}),
                use_container_width=True,
            )


# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 — Summary table
# ══════════════════════════════════════════════════════════════════════════════

with tab2:
    st.subheader(f"Shareholding summary — {len(filtered_symbols)} stocks")

    def color_fii_chg(val):
        if pd.isna(val): return ""
        if val > 0:  return "color: #1e7e34; font-weight: 500"
        if val < 0:  return "color: #c0392b; font-weight: 500"
        return ""

    pct_cols = [c for c in summary.columns if c.endswith(" %")]
    chg_cols = [c for c in summary.columns if c.endswith(" QoQ")]

    fmt = {c: "{:.2f}%" for c in pct_cols + chg_cols}

    styled = (
        summary.style
        .format(fmt, na_rep="—")
        .applymap(color_fii_chg, subset=[c for c in chg_cols if "FII" in c])
        .set_properties(**{"font-size": "13px"})
    )
    st.dataframe(styled, use_container_width=True, height=500)

    csv_bytes = summary.to_csv(index=False).encode()
    st.download_button("⬇ Download as CSV", csv_bytes, "shareholding_summary.csv", "text/csv")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 — FII heatmap
# ══════════════════════════════════════════════════════════════════════════════

with tab3:
    st.subheader("FII % heatmap across all stocks and quarters")

    cat_choice = st.selectbox(
        "Category to heatmap",
        options=[c for c in ["FIIs","DIIs","Promoters","Public"] if c in df_all["category"].unique()],
        key="hm_cat",
    )

    hm_data = df_all[
        (df_all["symbol"].isin(filtered_symbols)) &
        (df_all["category"] == cat_choice)
    ].copy()
    hm_data = sort_quarters(hm_data)

    if hm_data.empty:
        st.info("No data for selected combination.")
    else:
        pivot = hm_data.pivot_table(
            index="symbol", columns="quarter", values="pct", aggfunc="first"
        )
        pivot.columns = pivot.columns.astype(str)

        # Sort by latest quarter descending
        last_col = pivot.columns[-1]
        pivot = pivot.sort_values(last_col, ascending=False)

        color_scale = "Blues" if cat_choice == "FIIs" else (
            "Greens" if cat_choice == "DIIs" else
            "Greys"  if cat_choice == "Promoters" else "Oranges"
        )

        fig_hm = px.imshow(
            pivot,
            aspect="auto",
            color_continuous_scale=color_scale,
            labels=dict(color=f"{cat_choice} %"),
            title=f"{cat_choice} shareholding % heatmap",
        )
        fig_hm.update_traces(
            hovertemplate="<b>%{y}</b><br>Quarter: %{x}<br>%{z:.2f}%<extra></extra>",
            texttemplate="%{z:.1f}",
            textfont_size=9,
        )
        fig_hm.update_layout(
            height=max(400, len(pivot) * 20 + 100),
            xaxis_title="Quarter",
            yaxis_title="",
            margin=dict(l=100, r=20, t=50, b=60),
            coloraxis_colorbar=dict(ticksuffix="%"),
        )
        st.plotly_chart(fig_hm, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# TAB 4 — Cross-stock compare
# ══════════════════════════════════════════════════════════════════════════════

with tab4:
    st.subheader("Compare FII % across multiple stocks")

    col_a, col_b = st.columns([2, 1])
    with col_a:
        compare_syms = st.multiselect(
            "Pick stocks to compare",
            options=filtered_symbols or symbols,
            default=(filtered_symbols or symbols)[:min(8, len(filtered_symbols or symbols))],
            key="cmp_syms",
        )
    with col_b:
        cmp_cat = st.selectbox(
            "Category",
            options=[c for c in ["FIIs","DIIs","Promoters","Public"] if c in df_all["category"].unique()],
            key="cmp_cat",
        )

    if not compare_syms:
        st.info("Select at least one stock.")
    else:
        cmp_data = df_all[
            df_all["symbol"].isin(compare_syms) &
            (df_all["category"] == cmp_cat)
        ].copy()
        cmp_data = sort_quarters(cmp_data)

        fig_cmp = go.Figure()
        palette = px.colors.qualitative.D3
        for idx, sym in enumerate(compare_syms):
            sym_df = cmp_data[cmp_data["symbol"] == sym]
            if sym_df.empty:
                continue
            fig_cmp.add_trace(go.Scatter(
                x=sym_df["quarter"].astype(str),
                y=sym_df["pct"],
                name=sym,
                mode="lines+markers",
                line=dict(width=2, color=palette[idx % len(palette)]),
                marker=dict(size=5),
                hovertemplate=f"<b>{sym}</b><br>%{{x}}<br>%{{y:.2f}}%<extra></extra>",
            ))

        fig_cmp.update_layout(
            title=f"{cmp_cat} % — multi-stock comparison",
            xaxis_title="Quarter",
            yaxis_title=f"{cmp_cat} %",
            yaxis_ticksuffix="%",
            hovermode="x unified",
            template="plotly_white",
            legend=dict(orientation="h", y=-0.25, font_size=11),
            margin=dict(l=40, r=20, t=50, b=80),
            height=440,
        )
        st.plotly_chart(fig_cmp, use_container_width=True)

        # Latest-quarter bar chart
        st.markdown("#### Latest quarter snapshot")
        latest_q_data = (
            cmp_data
            .sort_values("quarter")
            .groupby("symbol")
            .last()
            .reset_index()
            [["symbol","pct","quarter"]]
            .sort_values("pct", ascending=False)
        )
        fig_bar = px.bar(
            latest_q_data,
            x="symbol", y="pct",
            color="pct",
            color_continuous_scale="Blues",
            labels={"pct": f"{cmp_cat} %", "symbol": "Stock"},
            text=latest_q_data["pct"].apply(lambda v: f"{v:.1f}%"),
            title=f"{cmp_cat} % — latest quarter ({latest_q_data['quarter'].iloc[0] if not latest_q_data.empty else ''})",
        )
        fig_bar.update_traces(textposition="outside")
        fig_bar.update_layout(
            yaxis_ticksuffix="%",
            template="plotly_white",
            coloraxis_showscale=False,
            height=360,
            margin=dict(l=40, r=20, t=50, b=40),
        )
        st.plotly_chart(fig_bar, use_container_width=True)
