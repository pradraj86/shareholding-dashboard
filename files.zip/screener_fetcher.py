"""
screener_fetcher.py
───────────────────
Fetches quarterly shareholding pattern (Promoters / FIIs / DIIs / Public)
from Screener.in for every stock in your TradingView watchlist.

Usage
-----
1. Set SESSION_ID below (copy sessionid cookie from browser after logging in).
2. Run:  python screener_fetcher.py
3. Data saved to:  data/shareholding_screener/  (one CSV per stock)
                   data/shareholding_all.csv     (combined master file)

Requirements
------------
    pip install requests pandas beautifulsoup4 lxml
"""

import time
import logging
import re
from pathlib import Path

import requests
import pandas as pd
from bs4 import BeautifulSoup

# ─── CONFIGURATION ────────────────────────────────────────────────────────────

SESSION_ID = "kwe6vuy1vx4jsbxl04k7go2tm5et27f7"   # ← paste your Screener sessionid here
WATCHLIST_FILE = Path("watchlist.txt")
OUT_DIR = Path("data/shareholding_screener")
MASTER_CSV = Path("data/shareholding_all.csv")

DELAY_BETWEEN_REQUESTS = 1.5   # seconds — be polite to Screener
MAX_RETRIES = 2

# ─── LOGGING ──────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("logs/screener_fetch.log", encoding="utf-8"),
    ],
)
log = logging.getLogger(__name__)

# ─── HELPERS ──────────────────────────────────────────────────────────────────

KNOWN_EXCHANGES = {"NSE", "BSE", "NIFTY"}

def parse_watchlist(filepath: Path = WATCHLIST_FILE) -> list[str]:
    """Parse TradingView watchlist TXT → clean NSE symbols."""
    if not filepath.exists():
        log.warning(f"Watchlist not found at {filepath}. Using defaults.")
        return ["RELIANCE", "INFY", "HDFCBANK", "TCS", "ICICIBANK"]

    symbols, seen = [], set()
    for line in filepath.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("###"):
            continue
        for part in line.split(","):
            part = part.strip()
            if not part or part.startswith("###"):
                continue
            if ":" in part:
                exchange, sym = part.split(":", 1)
                if exchange.upper() in KNOWN_EXCHANGES:
                    sym = sym.strip().upper()
                    if sym not in seen:
                        seen.add(sym)
                        symbols.append(sym)
            else:
                sym = re.sub(r"[^A-Z0-9&]", "", part.upper())
                if sym and sym not in seen:
                    seen.add(sym)
                    symbols.append(sym)
    log.info(f"Loaded {len(symbols)} symbols from watchlist.")
    return symbols


def make_session(session_id: str) -> requests.Session:
    """Create an authenticated Screener.in session."""
    s = requests.Session()
    s.headers.update({
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-IN,en;q=0.9",
        "Referer": "https://www.screener.in/",
    })
    s.cookies.set("sessionid", session_id, domain="www.screener.in")
    return s


# ─── PARSER ───────────────────────────────────────────────────────────────────

def parse_shareholding_page(html: str, symbol: str) -> pd.DataFrame | None:
    """
    Extract the shareholding table from a Screener.in company page.

    Returns a tidy DataFrame with columns:
        symbol | quarter | category | pct
    or None if the table is not found.
    """
    soup = BeautifulSoup(html, "lxml")

    # Screener renders shareholding inside a section with id="shareholding"
    section = soup.find("section", {"id": "shareholding"})
    if not section:
        # Fallback: find any table whose header contains "Promoters"
        for tbl in soup.find_all("table"):
            header_text = tbl.get_text()
            if "Promoters" in header_text and "FIIs" in header_text:
                section = tbl.parent
                break

    if not section:
        log.warning(f"{symbol}: shareholding section not found on page.")
        return None

    table = section.find("table")
    if not table:
        log.warning(f"{symbol}: no table inside shareholding section.")
        return None

    # ── Parse header row → quarter labels ─────────────────────────────────────
    header_row = table.find("thead")
    if not header_row:
        rows = table.find_all("tr")
        header_cells = [td.get_text(strip=True) for td in rows[0].find_all(["th", "td"])]
    else:
        header_cells = [td.get_text(strip=True) for td in header_row.find_all(["th", "td"])]

    # First cell is category label, rest are quarters
    quarters = header_cells[1:]
    if not quarters:
        log.warning(f"{symbol}: no quarter columns found.")
        return None

    # ── Parse data rows ────────────────────────────────────────────────────────
    tbody = table.find("tbody") or table
    records = []
    for row in tbody.find_all("tr"):
        cells = row.find_all(["td", "th"])
        if not cells:
            continue
        category = cells[0].get_text(strip=True)
        if not category:
            continue
        # Clean up category names
        category = (
            category
            .replace("%", "")
            .replace("+", "")
            .strip()
        )
        values = []
        for cell in cells[1:]:
            raw = cell.get_text(strip=True).replace(",", "").replace("%", "")
            try:
                values.append(float(raw))
            except ValueError:
                values.append(None)

        for q, v in zip(quarters, values):
            records.append({
                "symbol": symbol,
                "quarter": q,
                "category": category,
                "pct": v,
            })

    if not records:
        log.warning(f"{symbol}: table parsed but no data rows found.")
        return None

    df = pd.DataFrame(records)
    df = df[df["pct"].notna()]

    # Keep only the standard categories
    keep = {"Promoters", "FIIs", "DIIs", "Public", "Govt", "Others"}
    df = df[df["category"].apply(lambda c: any(k.lower() in c.lower() for k in keep))]

    return df if not df.empty else None


# ─── FETCHER ──────────────────────────────────────────────────────────────────

def fetch_symbol(session: requests.Session, symbol: str) -> pd.DataFrame | None:
    """Fetch and parse shareholding for one symbol. Returns tidy DataFrame or None."""
    # Screener uses the NSE symbol directly; some symbols need a suffix like /consolidated/
    urls = [
        f"https://www.screener.in/company/{symbol}/",
        f"https://www.screener.in/company/{symbol}/consolidated/",
    ]
    for url in urls:
        for attempt in range(1, MAX_RETRIES + 2):
            try:
                r = session.get(url, timeout=20)
                if r.status_code == 200:
                    df = parse_shareholding_page(r.text, symbol)
                    if df is not None:
                        log.info(f"✓ {symbol}: {len(df)} rows ({df['quarter'].nunique()} quarters)")
                        return df
                    # Page loaded but no table — try consolidated URL
                    break
                elif r.status_code == 404:
                    log.debug(f"{symbol}: 404 at {url}")
                    break   # try next URL
                else:
                    log.warning(f"{symbol}: HTTP {r.status_code} (attempt {attempt})")
                    time.sleep(2)
            except requests.RequestException as e:
                log.warning(f"{symbol}: request error (attempt {attempt}): {e}")
                time.sleep(2)

    log.error(f"✗ {symbol}: all attempts failed.")
    return None


# ─── MAIN LOOP ────────────────────────────────────────────────────────────────

def run(session_id: str = SESSION_ID, symbols: list[str] | None = None):
    """
    Fetch shareholding for all symbols and save CSVs.

    Parameters
    ----------
    session_id : str
        Screener.in session cookie value.
    symbols : list[str] | None
        Override symbol list (defaults to watchlist.txt).
    """
    Path("logs").mkdir(exist_ok=True)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    MASTER_CSV.parent.mkdir(parents=True, exist_ok=True)

    if symbols is None:
        symbols = parse_watchlist()

    session = make_session(session_id)

    # Warm up the session (get CSRF token / cookies)
    try:
        session.get("https://www.screener.in/", timeout=10)
        time.sleep(0.5)
    except Exception:
        pass

    all_frames = []
    total = len(symbols)

    for i, sym in enumerate(symbols, 1):
        out_path = OUT_DIR / f"shareholding_{sym}.csv"

        # Skip if already fetched successfully today
        if out_path.exists():
            try:
                cached = pd.read_csv(out_path)
                if not cached.empty:
                    log.info(f"[{i}/{total}] {sym}: using cached data ({len(cached)} rows)")
                    all_frames.append(cached)
                    continue
            except Exception:
                pass

        log.info(f"[{i}/{total}] Fetching {sym}…")
        df = fetch_symbol(session, sym)

        if df is not None:
            df.to_csv(out_path, index=False)
            all_frames.append(df)
        else:
            # Save an empty marker so we don't retry on next run
            pd.DataFrame(columns=["symbol", "quarter", "category", "pct"]).to_csv(out_path, index=False)

        time.sleep(DELAY_BETWEEN_REQUESTS)

    # ── Save master combined CSV ───────────────────────────────────────────────
    if all_frames:
        master = pd.concat(all_frames, ignore_index=True)
        master.to_csv(MASTER_CSV, index=False)
        log.info(f"\n✅ Done! {len(all_frames)} stocks saved.")
        log.info(f"   Per-stock CSVs : {OUT_DIR}/")
        log.info(f"   Master CSV     : {MASTER_CSV}")
        return master
    else:
        log.error("No data fetched.")
        return pd.DataFrame()


# ─── ENTRY POINT ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    master_df = run()
    if not master_df.empty:
        print(f"\nSample output:\n{master_df.head(12).to_string(index=False)}")
